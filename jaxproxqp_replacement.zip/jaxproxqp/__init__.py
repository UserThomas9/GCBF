"""
Minimal JaxProxQP replacement for GCBF+.

Solves box-constrained QPs of the form:
  min  0.5 x^T H x + g^T x
  s.t. C x <= b
       l_box <= x <= u_box

Uses a simple projected gradient descent approach that's
differentiable through JAX. Not as fast as ProxQP but
sufficient for GCBF+ training.
"""

import jax
import jax.numpy as jnp
from functools import partial
from typing import NamedTuple, Optional


class QPSolution(NamedTuple):
    x: jnp.ndarray
    converged: bool


class JaxProxQP:
    """Drop-in replacement for jaxproxqp.JaxProxQP."""

    class Settings(NamedTuple):
        max_iter: int = 1000
        eps_abs: float = 1e-6
        dua_gap_thresh_abs: Optional[float] = None

        @staticmethod
        def default():
            return JaxProxQP.Settings()

    class QPModel(NamedTuple):
        H: jnp.ndarray
        g: jnp.ndarray
        C: jnp.ndarray
        b: jnp.ndarray
        l_box: jnp.ndarray
        u_box: jnp.ndarray

        @staticmethod
        def create(H, g, C, b, l_box, u_box):
            return JaxProxQP.QPModel(H=H, g=g, C=C, b=b,
                                      l_box=l_box, u_box=u_box)

    def __init__(self, qp_model, settings=None):
        self.qp = qp_model
        self.settings = settings or JaxProxQP.Settings.default()

    def solve(self):
        H, g, C, b = self.qp.H, self.qp.g, self.qp.C, self.qp.b
        l_box, u_box = self.qp.l_box, self.qp.u_box
        n = H.shape[0]

        # Initialize at midpoint of box constraints
        x = jnp.clip(jnp.zeros(n), l_box, u_box)

        # Projected gradient descent with inequality constraints
        # Use augmented Lagrangian for Cx <= b
        mu = jnp.zeros(C.shape[0])  # dual variables
        rho = 10.0  # penalty parameter

        def body_fn(carry, _):
            x, mu = carry
            # Gradient of augmented Lagrangian
            cx = C @ x - b
            violation = jnp.maximum(cx + mu / rho, 0.0)
            grad = H @ x + g + C.T @ (rho * violation)

            # Step size (conservative)
            step = 0.01 / (jnp.linalg.norm(jnp.diag(H)) + rho * jnp.linalg.norm(C.T @ C) + 1e-6)
            x_new = x - step * grad
            x_new = jnp.clip(x_new, l_box, u_box)

            # Update dual
            mu_new = jnp.maximum(mu + rho * (C @ x_new - b), 0.0)

            return (x_new, mu_new), None

        (x_sol, _), _ = jax.lax.scan(body_fn, (x, mu), None,
                                       length=self.settings.max_iter)

        return QPSolution(x=x_sol, converged=True)
